<footer class="footer footer-alt">
             - <?php echo date ('Y');?> &copy;Clover Hospital Management System</a> 
</footer>